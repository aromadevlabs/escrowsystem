RegisterNetEvent('qx:ping')
