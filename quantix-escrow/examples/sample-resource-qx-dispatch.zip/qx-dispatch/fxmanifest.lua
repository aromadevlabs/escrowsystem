fx_version 'cerulean'
game 'gta5'
lua54 'yes'
name 'qx-dispatch'
version '1.2.0'
description 'Quantix dispatch system'
author 'Quantix Labs'

shared_scripts { 'shared/config.lua', 'locales/en.lua' }
client_scripts { 'client/main.lua' }
server_scripts { 'server/main.lua', 'server/api.lua' }
ui_page 'html/index.html'
files { 'html/index.html', 'html/style.css' }
