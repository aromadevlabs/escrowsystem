print('client secret logic '..tostring(Config.blips))
