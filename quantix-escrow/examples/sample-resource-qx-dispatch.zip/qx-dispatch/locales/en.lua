Locales = { en = { hello = 'hi' } }
